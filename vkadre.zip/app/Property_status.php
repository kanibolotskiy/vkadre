<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Property_status extends Model
{
    //
}
