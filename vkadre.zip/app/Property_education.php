<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Property_education extends Model
{
    //
}
