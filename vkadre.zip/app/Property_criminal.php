<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Property_criminal extends Model
{
    //
}
