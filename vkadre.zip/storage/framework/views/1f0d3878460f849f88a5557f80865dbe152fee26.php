<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel React application</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
        <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet" type="text/css">
        
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #000;
                font-family: 'Roboto';
                font-size:13px;
                font-weight: 200;
                height: 100vh;
                margin: 0;
                padding:0;
            }
        </style>

    </head>
    <body>
        <header style="padding:10px;">
            <div className="header_info" style="display:flex;">
                <div className="header_item">Сотрудники</div>
                <div className="header_item">Изменения</div>
                <div className="header_item">Настройки</div>
                <div className="header_item">Выход</div>
            </div>
        </header>
        <div id="root"></div>
        <script src="<?php echo e(mix('js/app.js')); ?>" ></script>
    </body>
</html>
<?php /**PATH D:\projects\Laravel\vkadre\resources\views/properties.blade.php ENDPATH**/ ?>