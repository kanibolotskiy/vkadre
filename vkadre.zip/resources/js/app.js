/*require('./bootstrap'); 
import Main from './components/Main';
*/

require('./bootstrap');
require('./components/Main');
